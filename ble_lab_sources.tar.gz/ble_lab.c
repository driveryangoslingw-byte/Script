#include "ble_lab_config.h"
#include "ble_lab_profile.h"
#include "ble_lab_util.h"

#include <bt/bt_service/bt.h>
#include <furi.h>
#include <furi_hal_bt.h>
#include <furi_hal_version.h>
#include <gui/gui.h>
#include <input/input.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAG "BLELab"
#define GAP_TIMEOUT_MS 2500U

typedef enum {
    LabIdle,
    LabRunning,
    LabDone,
    LabStopped,
    LabError,
} LabRunState;

typedef enum {
    LabFaultNone = 0,
    LabFaultRadio = 1,
    LabFaultInterval = 2,
    LabFaultProfile = 3,
    LabFaultGapTimeout = 4,
    LabFaultControllerUnavailable = 5,
    LabFaultRestore = 6,
} LabFault;

typedef struct {
    LabRunState run_state;
    uint8_t mode;
    uint8_t slot;
    uint8_t address[6];
    uint32_t secs_remaining;
    uint32_t sessions_started; // GAP-reported sessions; NOT RF packet measurements
    uint32_t faults;
    LabFault last_fault;
    BtStatus bt_status;
} LabSnapshot;

typedef struct {
    Gui* gui;
    ViewPort* viewport;
    Bt* bt;
    FuriMessageQueue* input_queue;
    FuriMutex* lock;
    LabSnapshot s;
    uint8_t own_mac[6];
    bool owns_profile;
    uint32_t run_started_tick;
} LabApp;

static LabSnapshot lab_snapshot(LabApp* app) {
    furi_mutex_acquire(app->lock, FuriWaitForever);
    LabSnapshot state = app->s;
    furi_mutex_release(app->lock);
    return state;
}

static void lab_set_state(LabApp* app, LabRunState state) {
    furi_mutex_acquire(app->lock, FuriWaitForever);
    app->s.run_state = state;
    furi_mutex_release(app->lock);
    view_port_update(app->viewport);
}

static void lab_fault(LabApp* app, LabFault fault, const char* detail) {
    furi_mutex_acquire(app->lock, FuriWaitForever);
    app->s.faults++;
    app->s.last_fault = fault;
    app->s.run_state = LabError;
    furi_mutex_release(app->lock);
    FURI_LOG_E(TAG, "fault=%u %s", (unsigned)fault, detail);
    // Keep the controller's own debug state in the Flipper log for diagnosis.
    FuriString* state = furi_string_alloc();
    furi_hal_bt_dump_state(state);
    FURI_LOG_E(TAG, "BLE state: %s", furi_string_get_cstr(state));
    furi_string_free(state);
    view_port_update(app->viewport);
}

static void lab_bt_status_cb(BtStatus status, void* ctx) {
    LabApp* app = ctx;
    furi_mutex_acquire(app->lock, FuriWaitForever);
    app->s.bt_status = status;
    furi_mutex_release(app->lock);
}

static const char* lab_state_text(LabRunState state) {
    switch(state) {
    case LabRunning: return "RUNNING  BACK=stop";
    case LabDone: return "DONE 60s   BACK=exit";
    case LabStopped: return "STOPPED    BACK=exit";
    case LabError: return "ERROR      BACK=exit";
    default: return "OK=start  BACK=exit";
    }
}

static void lab_draw(Canvas* canvas, void* ctx) {
    LabApp* app = ctx;
    LabSnapshot s = lab_snapshot(app);
    char line[46];
    uint8_t count = lab_identity_count(s.mode);
    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 2, 10, "BLE Identity Lab");
    canvas_set_font(canvas, FontSecondary);

    snprintf(line, sizeof(line), "Profiles: %u  [LEFT/RIGHT]", (unsigned)count);
    canvas_draw_str(canvas, 2, 20, line);
    canvas_draw_str(canvas, 2, 28, "ADV_IND  80-100ms fixed");
    canvas_draw_str(canvas, 2, 36, lab_state_text(s.run_state));

    snprintf(line, sizeof(line), "ID:%u/%u Sessions:%lu  T:%lus",
        (unsigned)(s.sessions_started ? (s.slot + 1U) : 0U),
        (unsigned)count,
        (unsigned long)s.sessions_started,
        (unsigned long)s.secs_remaining);
    canvas_draw_str(canvas, 2, 45, line);

    snprintf(line, sizeof(line), "MAC %02X:%02X:%02X:%02X:%02X:%02X",
        s.address[5], s.address[4], s.address[3],
        s.address[2], s.address[1], s.address[0]);
    canvas_draw_str(canvas, 2, 54, line);

    snprintf(line, sizeof(line), "GAP:%d  Faults:%lu Last:%u",
        (int)s.bt_status, (unsigned long)s.faults, (unsigned)s.last_fault);
    canvas_draw_str(canvas, 2, 62, line);
}

static void lab_input_cb(InputEvent* event, void* ctx) {
    FuriMessageQueue* queue = ctx;
    if(event->type == InputTypeShort || event->type == InputTypeLong) {
        furi_message_queue_put(queue, event, 0);
    }
}

static bool lab_stop_and_restore(LabApp* app) {
    if(!app->owns_profile) return true;
    FURI_LOG_I(TAG, "Stop ADV and restore standard BLE profile");
    furi_hal_bt_stop_advertising();
    bt_disconnect(app->bt);
    // Avoid stale status callback events while the BT service changes its profile.
    bt_set_status_changed_callback(app->bt, NULL, NULL);
    bool ok = bt_profile_restore_default(app->bt);
    app->owns_profile = false;
    bt_set_status_changed_callback(app->bt, lab_bt_status_cb, app);
    if(!ok) FURI_LOG_E(TAG, "Unable to restore default BLE profile");
    return ok;
}

static bool lab_start_slot(LabApp* app, uint8_t slot) {
    if(!lab_adv_interval_valid(LAB_ADV_MIN_MS, LAB_ADV_MAX_MS)) {
        lab_fault(app, LabFaultInterval, "Invalid firmware ADV timing");
        return false;
    }
    if(!furi_hal_bt_is_alive() || !furi_hal_bt_is_gatt_gap_supported()) {
        lab_fault(app, LabFaultRadio, "GAP not available");
        return false;
    }

    LabProfileParams p = {.slot = slot};
    lab_derive_mac(app->own_mac, slot, p.address);
    // Stop the previous connectable advertiser before asking BT to use a new MAC.
    if(app->owns_profile) {
        furi_hal_bt_stop_advertising();
        bt_disconnect(app->bt);
    }

    furi_mutex_acquire(app->lock, FuriWaitForever);
    app->s.bt_status = BtStatusOff;
    furi_mutex_release(app->lock);
    // bt_profile_start() synchronously asks the BT service to restart CPU2,
    // load this profile, and configure GAP with the new address and AD data.
    app->owns_profile = true; // also restore defaults after a failed restart
    FuriHalBleProfileBase* profile = bt_profile_start(app->bt, ble_lab_profile, &p);
    if(!profile) {
        lab_fault(app, LabFaultProfile, "bt_profile_start returned NULL");
        return false;
    }
    // BT service may already have requested advertising; this call is idempotent.
    furi_hal_bt_start_advertising();

    uint32_t timeout_ticks = GAP_TIMEOUT_MS * furi_kernel_get_tick_frequency() / 1000U;
    uint32_t began = furi_get_tick();
    bool gap_reported = false;
    while((uint32_t)(furi_get_tick() - began) < timeout_ticks) {
        BtStatus status = lab_snapshot(app).bt_status;
        if(status == BtStatusAdvertising || status == BtStatusConnected) {
            gap_reported = true;
            break;
        }
        if(status == BtStatusUnavailable) break;
        furi_delay_ms(25);
    }
    if(!gap_reported) {
        lab_fault(app, LabFaultGapTimeout, "GAP advertising start not reported");
        return false;
    }

    furi_mutex_acquire(app->lock, FuriWaitForever);
    app->s.slot = slot;
    memcpy(app->s.address, p.address, sizeof(p.address));
    app->s.sessions_started++;
    furi_mutex_release(app->lock);
    FURI_LOG_I(TAG, "GAP session %lu: BLELAB-%02u addr=%02X:%02X:%02X:%02X:%02X:%02X",
        (unsigned long)lab_snapshot(app).sessions_started, (unsigned)(slot + 1U),
        p.address[5], p.address[4], p.address[3], p.address[2], p.address[1], p.address[0]);
    view_port_update(app->viewport);
    return true;
}

static void lab_start_run(LabApp* app) {
    if(!lab_stop_and_restore(app)) {
        lab_fault(app, LabFaultRestore, "Failed restore before test");
        return;
    }
    furi_mutex_acquire(app->lock, FuriWaitForever);
    app->s.sessions_started = 0;
    app->s.faults = 0;
    app->s.last_fault = LabFaultNone;
    app->s.slot = 0;
    app->s.bt_status = BtStatusOff;
    app->s.secs_remaining = LAB_DURATION_S;
    memset(app->s.address, 0, sizeof(app->s.address));
    app->s.run_state = LabRunning;
    furi_mutex_release(app->lock);
    if(!lab_start_slot(app, 0)) {
        if(!lab_stop_and_restore(app)) {
            lab_fault(app, LabFaultRestore, "Failed to restore after start error");
        }
        return;
    }
    // Exactly 60 seconds of test time from the first reported GAP start.
    app->run_started_tick = furi_get_tick();
}

static void lab_update_run(LabApp* app) {
    LabSnapshot snap = lab_snapshot(app);
    if(snap.run_state != LabRunning) return;

    if(snap.bt_status == BtStatusUnavailable) {
        lab_fault(app, LabFaultControllerUnavailable, "Controller reported unavailable");
        if(!lab_stop_and_restore(app)) lab_fault(app, LabFaultRestore, "Restore failed");
        return;
    }

    const uint32_t ticks_per_second = furi_kernel_get_tick_frequency();
    const uint32_t total = LAB_DURATION_S * ticks_per_second;
    const uint32_t elapsed = (uint32_t)(furi_get_tick() - app->run_started_tick);
    if(elapsed >= total) {
        if(!lab_stop_and_restore(app)) {
            lab_fault(app, LabFaultRestore, "Restore failed at test end");
            return;
        }
        furi_mutex_acquire(app->lock, FuriWaitForever);
        app->s.secs_remaining = 0;
        app->s.run_state = LabDone;
        furi_mutex_release(app->lock);
        view_port_update(app->viewport);
        return;
    }

    uint32_t remaining = (total - elapsed + ticks_per_second - 1U) / ticks_per_second;
    uint8_t identities = lab_identity_count(snap.mode);
    uint8_t slot_due = (uint8_t)(((uint64_t)elapsed * identities) / total);
    furi_mutex_acquire(app->lock, FuriWaitForever);
    app->s.secs_remaining = remaining;
    furi_mutex_release(app->lock);

    // Single pass only. If CPU2 restart was slow, skip missed IDs (no burst).
    if(slot_due > snap.slot) {
        if(!lab_start_slot(app, slot_due)) {
            if(!lab_stop_and_restore(app)) {
                lab_fault(app, LabFaultRestore, "Restore failed on test error");
            }
        }
    }
    view_port_update(app->viewport);
}

int32_t ble_identity_lab_app(void* args) {
    UNUSED(args);
    LabApp* app = malloc(sizeof(LabApp));
    if(!app) return -1;
    memset(app, 0, sizeof(*app));
    app->lock = furi_mutex_alloc(FuriMutexTypeNormal);
    app->input_queue = furi_message_queue_alloc(16, sizeof(InputEvent));
    app->viewport = view_port_alloc();
    app->s.secs_remaining = LAB_DURATION_S;
    app->s.run_state = LabIdle;
    app->s.bt_status = BtStatusOff;
    memcpy(app->own_mac, furi_hal_version_get_ble_mac(), 6);
    app->bt = furi_record_open(RECORD_BT);
    app->gui = furi_record_open(RECORD_GUI);
    view_port_draw_callback_set(app->viewport, lab_draw, app);
    view_port_input_callback_set(app->viewport, lab_input_cb, app->input_queue);
    gui_add_view_port(app->gui, app->viewport, GuiLayerFullscreen);
    bt_set_status_changed_callback(app->bt, lab_bt_status_cb, app);

    bool quit = false;
    while(!quit) {
        InputEvent event;
        if(furi_message_queue_get(app->input_queue, &event, 50) == FuriStatusOk) {
            LabSnapshot s = lab_snapshot(app);
            if(event.key == InputKeyBack) {
                if(s.run_state == LabRunning) {
                    if(lab_stop_and_restore(app)) lab_set_state(app, LabStopped);
                    else lab_fault(app, LabFaultRestore, "BACK: profile restoration failed");
                } else {
                    quit = true;
                }
            } else if(s.run_state != LabRunning && event.type == InputTypeShort) {
                if(event.key == InputKeyOk) {
                    lab_start_run(app);
                } else if(event.key == InputKeyLeft || event.key == InputKeyRight) {
                    furi_mutex_acquire(app->lock, FuriWaitForever);
                    app->s.mode = (uint8_t)((app->s.mode +
                        (event.key == InputKeyRight ? 1U : 2U)) % 3U);
                    app->s.run_state = LabIdle;
                    furi_mutex_release(app->lock);
                }
            }
        }
        lab_update_run(app);
        view_port_update(app->viewport);
    }

    if(!lab_stop_and_restore(app)) {
        FURI_LOG_E(TAG, "Default BLE profile was not restored on exit");
    }
    bt_set_status_changed_callback(app->bt, NULL, NULL);
    gui_remove_view_port(app->gui, app->viewport);
    view_port_free(app->viewport);
    furi_record_close(RECORD_GUI);
    furi_record_close(RECORD_BT);
    furi_message_queue_free(app->input_queue);
    furi_mutex_free(app->lock);
    free(app);
    return 0;
}
