#pragma once

#define LAB_DURATION_S 60U
#define LAB_MAX_IDENTITIES 10U
#define LAB_ADV_MIN_MS 80U
#define LAB_ADV_MAX_MS 100U

/* Unmodified Unleashed-094 GAP uses fixed 80..100 ms fast advertising.
   This app changes identities only once per allocated dwell, not per ADV. */
