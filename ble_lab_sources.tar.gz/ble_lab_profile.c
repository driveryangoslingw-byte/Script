#include "ble_lab_profile.h"

#include <furi.h>
#include <gap.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// The firmware provides GAP (0x1800) and GATT (0x1801) and performs ADV_IND.
// This is a generic, connectable laboratory peripheral; not an accessory clone.
typedef struct {
    FuriHalBleProfileBase base;
} LabProfile;

static const FuriHalBleProfileTemplate lab_template;

static FuriHalBleProfileBase* lab_start(FuriHalBleProfileParams params) {
    UNUSED(params);
    LabProfile* profile = malloc(sizeof(LabProfile));
    if(!profile) return NULL;
    profile->base.config = &lab_template;
    return &profile->base;
}

static void lab_stop(FuriHalBleProfileBase* base) {
    if(!base) return;
    furi_check(base->config == &lab_template);
    free(base);
}

static void lab_gap_config(GapConfig* config, FuriHalBleProfileParams params) {
    const LabProfileParams* p = params;
    furi_check(config);
    furi_check(p);
    memset(config, 0, sizeof(*config));

    // 0x1800 = Generic Access service. GAP is already offered by controller.
    config->adv_service.UUID_Type = 0x01; // UUID_TYPE_16 on STM32 BLE stack
    config->adv_service.Service_UUID_16 = 0x1800;
    config->appearance_char = 0x0000;
    config->bonding_mode = false;
    config->pairing_method = GapPairingNone;
    config->conn_param.conn_int_min = 0x18; // 30ms, not ADV interval
    config->conn_param.conn_int_max = 0x28; // 50ms, not ADV interval
    config->conn_param.slave_latency = 0;
    config->conn_param.supervisor_timeout = 400; // 4 seconds
    memcpy(config->mac_address, p->address, sizeof(config->mac_address));

    // Unleashed-094 gap.c expects AD_TYPE at [0] and a zero-terminated name
    // at [1]. It constructs the advertising AD length via its GAP driver.
    config->adv_name[0] = 0x09; // Complete Local Name
    snprintf(&config->adv_name[1], sizeof(config->adv_name) - 1, "BLELAB-%02u", (unsigned)(p->slot + 1));

    // Firmware adds [length][0xFF] around mfg_data and places it in scan response.
    // 0xFFFF is a reserved test-only identifier, not a real company's identifier.
    config->mfg_data_len = 5;
    config->mfg_data[0] = 0xFF;
    config->mfg_data[1] = 0xFF;
    config->mfg_data[2] = 'L';
    config->mfg_data[3] = 'B';
    config->mfg_data[4] = (uint8_t)(p->slot + 1);
}

static const FuriHalBleProfileTemplate lab_template = {
    .start = lab_start,
    .stop = lab_stop,
    .get_gap_config = lab_gap_config,
};

const FuriHalBleProfileTemplate* ble_lab_profile = &lab_template;
