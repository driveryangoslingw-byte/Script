#pragma once

#include <furi_ble/profile_interface.h>
#include <stdint.h>

typedef struct {
    uint8_t slot;
    uint8_t address[6];
} LabProfileParams;

extern const FuriHalBleProfileTemplate* ble_lab_profile;
