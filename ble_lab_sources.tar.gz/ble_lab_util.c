#include "ble_lab_util.h"
#include <string.h>

uint8_t lab_identity_count(uint8_t mode) {
    static const uint8_t counts[] = {3, 5, 10};
    return (mode < 3U) ? counts[mode] : counts[0];
}

uint32_t lab_dwell_ms(uint8_t count) {
    return count ? 60000U / count : 0U;
}

bool lab_adv_interval_valid(uint16_t min_ms, uint16_t max_ms) {
    // BLE legacy connectable ADV intervals: 0x0020..0x4000 in 0.625ms units.
    // Accept only exactly representable whole milliseconds in this project.
    return min_ms >= 20 && max_ms <= 10240 && min_ms <= max_ms &&
           ((min_ms * 8U) % 5U == 0) && ((max_ms * 8U) % 5U == 0);
}

void lab_derive_mac(const uint8_t base[6], uint8_t slot, uint8_t out[6]) {
    // Flipper HAL passes the 6-byte public address in controller byte order.
    // Keep its original upper three bytes, varying only the three device bytes.
    // Never use another accessory's address or advertised identity.
    memcpy(out, base, 6);
    out[0] ^= (uint8_t)(0x41U + slot);
    out[1] ^= (uint8_t)(0xA1U + slot);
    out[2] ^= (uint8_t)(0x11U + slot);
}
