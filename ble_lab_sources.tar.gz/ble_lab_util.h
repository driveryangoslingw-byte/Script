#pragma once
#include <stdbool.h>
#include <stdint.h>

uint8_t lab_identity_count(uint8_t mode);
uint32_t lab_dwell_ms(uint8_t count);
bool lab_adv_interval_valid(uint16_t min_ms, uint16_t max_ms);
void lab_derive_mac(const uint8_t base[6], uint8_t slot, uint8_t out[6]);
